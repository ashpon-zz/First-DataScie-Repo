// @TODO: Uncomment the following file and complete the code  //
//        according to the instructions in README.md.


  
  var  hems = [ 
      {hem:"Cerberus Hemisphere Enhanced", imageUrl: "https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/cerberus_enhanced.tif/full.jpg"},
      {hem:"Schiaparelli Hemisphere Enhanced",imageUrl: "https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/schiaparelli_enhanced.tif/full.jpg"},
      {hem:"Syrtis Major Hemisphere Enhanced", imageUrl: "https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/syrtis_major_enhanced.tif/full.jpg"},
      {hem:"Valles Marineris Hemisphere Enhanced", imageUrl: "https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/valles_marineris_enhanced.tif/full.jpg"}
];


function renderHems() {
//  // Write code here to:
//  // 1. Get a reference to the element in the DOM with an id of todo-list using document.querySelector
    var factList = document.querySelector("#facts");

    var hdngMsg ="Mars Hemispheres";
    var todoHTML ="";
    
    // console.log("1 " + facts.length);
    // console.log("x " + facts[0].fact);
    // console.log("y " + facts[1].fact);

//  // 2. Using a for-loop, go through each element in the todos array and build a string containing an `li` element for each element in the todos array with the todo's text inside
    for (i=0; i<hems.length;i++){
      var liEle = document.createElement("li");
      liEle.innerHTML = hems[i].hem;
      factList.appendChild(liEle);
      var liEle = document.createElement("li");
      liEle.innerHTML = hems[i].imageUrl;
      factList.appendChild(liEle);
}
};

// // running the renderTodos function once the page loads

renderHems();
