# Going to Mars script 
# Loop through returned resultsfrom bs4 import BeautifulSoup as bs 

# import dependencies
import pandas as pd
import requests as req
from bs4 import BeautifulSoup as bs
from splinter import Browser
from flask import Flask


def scrape():
	#Define url to scrape
	url = "https://mars.nasa.gov/news/"

	#get response in a variable
	response = req.get(url)
	soup = bs(response.text, 'html.parser')

	# If required print values 
	print ("Scrapping :" + url)

	# get web page title
	title = soup.title.text
	print  ("Title is:" + title)

	# get article title 
	artTitle = soup.find('div',class_='content_title').text
	#print artTitle

	# article Body Here
	artBody = soup.find('div', class_='rollover_description_inner').text
	# print(artBody)

	executable_path = {'executable_path': 'c:/chromeSafe/chromedriver.exe'}
	browser = Browser('chrome', **executable_path)
	# url = 'http://quotes.toscrape.com/'
	url = 'https://www.jpl.nasa.gov/spaceimages/?search=featured&category=Mars#submit'
	browser.visit(url)
	html= browser.html
	soup_1 = bs(html,'html.parser')

	# get the images
	picList = []
	for aPath in soup_1.find_all('a', class_='fancybox'):
	    picPath = 'https://www.jpl.nasa.gov'+ aPath['data-fancybox-href']
	    picList.append(picPath)
	    print("The Pic Path: " + picPath)
  
	# print(picList[2])

	# get Mars facts 
	#create the dictionaries to hold values
	tagList = []
	valList = []

	factResp = req.get('https://space-facts.com/mars/')
	factSoup = bs(factResp.text, 'html.parser')

	
	for strong_tag in factSoup.find_all('td', class_='column-1'):
	    tagList.append(strong_tag.text)
	    print ("Loop 1: " + strong_tag.text)
	                 
	for strong_tag in factSoup.find_all('td', class_='column-2'):
	    valList.append(strong_tag.text)
	    print ("Loop 2: " + strong_tag.text)

	#Create a DataFrame
	theList = dict(zip(tagList,valList))
	mFactsDf = pd.DataFrame.from_records(theList,columns=['fact','val'])
	# factStr = mFactsDf.to_html()

	#remove two unwanted items
	# mFactsDf = mFactsDf.drop(mFactsDf.index[-1])
	# mFactsDf = mFactsDf.drop(mFactsDf.index[-1])
	print("Mars Facts Data Frame: " +mFactsDf)

	# get Mars Hemisphere Facts 
	#create the dictionaries to hold values
	tagList = []
	valList = []


	hemReq  = req.get('https://astrogeology.usgs.gov/search/results?q=hemisphere+enhanced&k1=target&v1=Mars')
	hemSoup = bs(hemReq.text, 'html.parser')
	# print("Hes Soup Here: " + hemSoup.text)

	# class_='item product-item'
	# get the hemispere page links, and titles
	hemLinks =[]
	for aHref in hemSoup.find_all('a', class_='item product-item'):
	    print ("Loop 3: " + aHref['href'])
	    hemLinks.append(aHref['href'])
	    
	hemTitle=[]
	for aHref in hemSoup.find_all('div', class_='description'):
	    print ("Loop 4: " + (aHref.find('h3')).text)
	    hemTitle.append((aHref.find('h3')).text)

	# will need to use splinter here
	hemImages=[]
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/cerberus_enhanced.tif/full.jpg')
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/schiaparelli_enhanced.tif/full.jpg')
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/syrtis_major_enhanced.tif/full.jpg')
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/valles_marineris_enhanced.tif/full.jpg')

	hemList = dict(zip(hemTitle,hemImages))
	# hemDict = dict(zip(hemList, theList))
	print("Step 5: " + str(hemList))
	
    
	# print("HemList: " + str(hemList.length()))
	# print("TheList: " + str(theList.length()))

	# print()
	# hemDict = {
	# 	"title: ": artTitle,
	# 	"body" : artBody,
	# 	"facts": factStr,
	# 	"HemTitles" : [hemTitle[0],hemTitle[1],hemTitle[2],hemTitle[3]],
	# 	"images" : [hemImages[0],hemImages[1],hemImages[2],hemImages[3]]
	# }
	hemDict = {
		"title: ": artTitle,
		"body" : artBody,
		"facts" : theList,
		"hems" : hemList
	}
	print("Step 6: " + str(hemDict))
	return hemDict
	# for ele in hemDict:
	# 	print("The Dict is: " + ehemle)


# create a function to insert data into Mongo
def wrtData(dataDict):
	from  pymongo import MongoClient

	client = MongoClient("mongodb://admin:Eagles27@ds241895.mlab.com:41895/heroku_q6flv9dt")

	db = client.heroku_q6flv9dt

	marsColl = db.mars_collection

	# setup the mars document
	marsDoc = dataDict

	# setup mars collection
	marsColl.insert(marsDoc)

	# import pprint
	# for coll in marsColl.find():
		# print(coll)

# call the scrape function for testing here 
scrp = scrape()
wrtData(scrp)