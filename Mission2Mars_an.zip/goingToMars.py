# Going to Mars script 
# Loop through returned resultsfrom bs4 import BeautifulSoup as bs 

# import dependencies
import pandas as pd
import requests as req
from bs4 import BeautifulSoup as bs
from splinter import Browser


def scrape():
	#Define url to scrape
	url = "https://mars.nasa.gov/news/"

	#get response in a variable
	response = req.get(url)
	soup = bs(response.text, 'html.parser')

	# If required
	# print (soup)

	# get web page title
	title = soup.title.text
	#print  (title)

	# get article title 
	artTitle = soup.find('div',class_='content_title').text
	#print artTitle

	# article Body Here
	artBody = soup.find('div', class_='rollover_description_inner').text
	# print(artBody)

	executable_path = {'executable_path': 'c:/chromeSafe/chromedriver.exe'}
	browser = Browser('chrome', **executable_path)
	# url = 'http://quotes.toscrape.com/'
	url = 'https://www.jpl.nasa.gov/spaceimages/?search=featured&category=Mars#submit'
	browser.visit(url)
	html= browser.html
	soup_1 = bs(html,'html.parser')

	# get the images
	picList = []
	for aPath in soup_1.find_all('a', class_='fancybox'):
	    picPath = 'https://www.jpl.nasa.gov'+ aPath['data-fancybox-href']
	    picList.append(picPath)
	    print(picPath)
  
	# print(picList[2])

	# get Mars facts 
	#create the dictionaries to hold values
	tagList = []
	valList = []

	factResp = req.get('https://space-facts.com/mars/')
	factSoup = bs(factResp.text, 'html.parser')

	seq = 0
	for strong_tag in factSoup.find_all('td', class_='column-1'):
	    tagList.append(strong_tag.text)
	#     print (strong_tag.text)
	                 
	for strong_tag in factSoup.find_all('td', class_='column-2'):
	    valList.append(strong_tag.text)
	#     print (strong_tag.text)

	#Create a DataFrame
	theList = zip(tagList,valList)
	mFactsDf = pd.DataFrame.from_records(theList,columns=['fact','val'])

	#remove two unwanted items
	mFactsDf = mFactsDf.drop(mFactsDf.index[-1])
	mFactsDf = mFactsDf.drop(mFactsDf.index[-1])
	# mFactsDf
	# get Mars Hemisphere Facts 
	#create the dictionaries to hold values
	tagList = []
	valList = []

	hemReq  = req.get('https://astrogeology.usgs.gov/search/results?q=hemisphere+enhanced&k1=target&v1=Mars')
	hemSoup = bs(factResp.text, 'html.parser')

	# class_='item product-item'
	# get the hemispere page links, and titles
	hemLinks =[]
	for aHref in hemSoup.find_all('a', class_='item product-item'):
	    print (aHref['href'])
	    hemLinks.append(aHref['href'])
	    
	hemTitle=[]
	for aHref in hemSoup.find_all('div', class_='description'):
	    print ((aHref.find('h3')).text)
	    hemTitle.append((aHref.find('h3')).text)

	# will need to use splinter here
	hemImages=[]
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/cerberus_enhanced.tif/full.jpg')
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/schiaparelli_enhanced.tif/full.jpg')
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/syrtis_major_enhanced.tif/full.jpg')
	hemImages.append('https://astropedia.astrogeology.usgs.gov/download/Mars/Viking/valles_marineris_enhanced.tif/full.jpg')

	hemList = zip(hemTitle,hemImages)
	hemDict = dict(zip(hemTitle,hemImages))
	print(hemDict)


scrape()