#import dependencies
from   scrape_mars import scrape
from flask import Flask



# create an app with a route scrape
# Flask setup
app = Flask(__name__)

@app.route("/")
def welcome():
    """List all available api routes."""
    print("Welcome to Mission to Mars!")
    usageStr = "Usage: /all_scrape - to get Mars Details"
    return "Welcome to Mission to Mars " + usageStr

@app.route("/all_scrape")
def all_scrape():
	# run the scrape function
	print("calling scrape")
	try:
		one = scrape()
		print("Response is: ", one)
		return one
	except:
		print("ERROR!!!")


if __name__ == '__main__':
    app.run(debug=True)
