

```python
# Dependencies
import pandas as pd
import numpy as np
import requests as req
import json
import random
import matplotlib.pyplot as plt
plt.style.use('seaborn-whitegrid')
from citipy import citipy
wKey = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'
```


```python
# # in the mean time work with cities from a csv
# Some random coordinates
#coordinates = [(0,25),(0,-160), (50,50), (100, 200), (23, 200), (42, 100),(10,150)]
coordinates = [((random.randrange(-90, 91)),(random.randrange(-180, 181))) for x in range (500)]
```


```python
# # select at least 500 unique cities 
# print("Get Sample Cities")
# citiesDf = citiesDf.sample(100)
citiesDf = []
cities = []
for coordinate_pair in coordinates:
    lat, lon = coordinate_pair
    cities.append(citipy.nearest_city(lat, lon))
    #print(citipy.nearest_city(lat, lon).city_name)
    
# print(len(cities))
# for i in range(len(cities)):
#      print ("here i: " + str(i) + " " +cities[i].city_name)    
```


```python
print("Loop through the cities and build the URL")
baseUrl = "http://api.openweathermap.org/data/2.5/weather?appid="+wKey

lats=[]
longs=[]
temps=[]
humids=[]
cloudies=[]
winds=[]
# Create an empty Data Frame to hold values so it can be saves as a csv
columns=["City","Lat","Long","Temp","Humidity","Cloudiness","Wind Speed"]
allValDf = pd.DataFrame(columns=columns)

print ("City Length:" + str(len(cities)))

for i in range(len(cities)-1):
    city = cities[i].city_name
    qUrl = baseUrl + "&q=" + city +"&unit=Imperial"
    print("Url for City: " + str(i) + ": " + city + "  "+qUrl)
    try:        
        response = req.get(qUrl).json()
        print("Processing for "+ city +" temp: " + str(response["main"]["temp"]) + " lat:" + str(response["coord"]["lat"]))
        cities.append(city)
        lats.append(response["coord"]["lat"])
        longs.append(response["coord"]["lon"])
        temps.append(response["main"]["temp"])
        humids.append(response["main"]["humidity"])
        cloudies.append(response["clouds"]["all"])
        winds.append(response["wind"]["speed"])
        #assign values to the allVal Data Frame
        data ={"City":city,"Lat": response["coord"]["lat"],"Long": response["coord"]["lon"], 
                             "Temprature": response["main"]["temp"],"Humidity":response["main"]["humidity"],
                             "Cloudiness": response["clouds"]["all"], "Wind Speed": response["wind"]["speed"]}
        allValDf = allValDf.append(data, ignore_index=True)
    except:
        print("Invalid Cityname: " , city)
        
   
```

    Loop through the cities and build the URL
    City Length:500
    Url for City: 0: carnarvon  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=carnarvon&unit=Imperial
    Processing for carnarvon temp: 290.96 lat:-24.87
    Url for City: 1: cave spring  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cave spring&unit=Imperial
    Processing for cave spring temp: 295.18 lat:37.23
    Url for City: 2: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 3: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 4: camapua  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=camapua&unit=Imperial
    Processing for camapua temp: 305.31 lat:-19.53
    Url for City: 5: tumannyy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tumannyy&unit=Imperial
    Processing for tumannyy temp: 278.71 lat:69.16
    Url for City: 6: bluff  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bluff&unit=Imperial
    Processing for bluff temp: 284.26 lat:-46.6
    Url for City: 7: kodiak  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kodiak&unit=Imperial
    Processing for kodiak temp: 286.15 lat:57.79
    Url for City: 8: katsuura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=katsuura&unit=Imperial
    Processing for katsuura temp: 295.15 lat:35.13
    Url for City: 9: upernavik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=upernavik&unit=Imperial
    Processing for upernavik temp: 275.41 lat:72.79
    Url for City: 10: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 11: poum  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=poum&unit=Imperial
    Processing for poum temp: 295.96 lat:-20.23
    Url for City: 12: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 13: tuktoyaktuk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tuktoyaktuk&unit=Imperial
    Processing for tuktoyaktuk temp: 284.15 lat:69.45
    Url for City: 14: rosario  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rosario&unit=Imperial
    Processing for rosario temp: 294.15 lat:-32.95
    Url for City: 15: inhambane  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=inhambane&unit=Imperial
    Processing for inhambane temp: 295.06 lat:-23.86
    Url for City: 16: campohermoso  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=campohermoso&unit=Imperial
    Processing for campohermoso temp: 296.15 lat:36.96
    Url for City: 17: vaini  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaini&unit=Imperial
    Processing for vaini temp: 296.15 lat:-21.2
    Url for City: 18: mao  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mao&unit=Imperial
    Processing for mao temp: 294.15 lat:39.89
    Url for City: 19: mahanoro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mahanoro&unit=Imperial
    Processing for mahanoro temp: 289.51 lat:-19.9
    Url for City: 20: prince rupert  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=prince rupert&unit=Imperial
    Processing for prince rupert temp: 288.15 lat:54.32
    Url for City: 21: ponta do sol  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ponta do sol&unit=Imperial
    Processing for ponta do sol temp: 295.15 lat:32.67
    Url for City: 22: punta alta  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta alta&unit=Imperial
    Processing for punta alta temp: 284.46 lat:-38.88
    Url for City: 23: ponta delgada  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ponta delgada&unit=Imperial
    Processing for ponta delgada temp: 296.15 lat:37.73
    Url for City: 24: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 25: jiuquan  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=jiuquan&unit=Imperial
    Processing for jiuquan temp: 292.01 lat:25.97
    Url for City: 26: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 27: inderborskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=inderborskiy&unit=Imperial
    Processing for inderborskiy temp: 291.01 lat:48.55
    Url for City: 28: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 29: ponta do sol  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ponta do sol&unit=Imperial
    Processing for ponta do sol temp: 295.15 lat:32.67
    Url for City: 30: arraial do cabo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=arraial do cabo&unit=Imperial
    Processing for arraial do cabo temp: 297.15 lat:-22.97
    Url for City: 31: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 32: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 33: magistralnyy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=magistralnyy&unit=Imperial
    Processing for magistralnyy temp: 273.16 lat:56.17
    Url for City: 34: lyaskelya  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lyaskelya&unit=Imperial
    Processing for lyaskelya temp: 284.91 lat:61.77
    Url for City: 35: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 36: bredasdorp  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bredasdorp&unit=Imperial
    Processing for bredasdorp temp: 283.15 lat:-34.53
    Url for City: 37: longyearbyen  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=longyearbyen&unit=Imperial
    Processing for longyearbyen temp: 277.15 lat:78.22
    Url for City: 38: santa maria  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=santa maria&unit=Imperial
    Processing for santa maria temp: 289.66 lat:-29.68
    Url for City: 39: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 40: upernavik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=upernavik&unit=Imperial
    Processing for upernavik temp: 275.41 lat:72.79
    Url for City: 41: lompoc  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lompoc&unit=Imperial
    Processing for lompoc temp: 296.11 lat:34.64
    Url for City: 42: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 43: victoria  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=victoria&unit=Imperial
    Processing for victoria temp: 293.35 lat:48.43
    Url for City: 44: cerrik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cerrik&unit=Imperial
    Processing for cerrik temp: 286.63 lat:41.03
    Url for City: 45: bengkulu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bengkulu&unit=Imperial
    Processing for bengkulu temp: 296.71 lat:-3.8
    Url for City: 46: atambua  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=atambua&unit=Imperial
    Processing for atambua temp: 296.86 lat:-9.11
    Url for City: 47: johi  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=johi&unit=Imperial
    Processing for johi temp: 298.61 lat:26.69
    Url for City: 48: avarua  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=avarua&unit=Imperial
    Processing for avarua temp: 300.15 lat:-21.21
    Url for City: 49: srandakan  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=srandakan&unit=Imperial
    Processing for srandakan temp: 294.96 lat:-7.94
    Url for City: 50: port elizabeth  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port elizabeth&unit=Imperial
    Processing for port elizabeth temp: 283.15 lat:-33.92
    Url for City: 51: fortuna  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=fortuna&unit=Imperial
    Processing for fortuna temp: 291.23 lat:40.6
    Url for City: 52: nsanje  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nsanje&unit=Imperial
    Processing for nsanje temp: 299.21 lat:-16.92
    Url for City: 53: thessalon  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=thessalon&unit=Imperial
    Processing for thessalon temp: 296.52 lat:46.25
    Url for City: 54: faanui  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=faanui&unit=Imperial
    Processing for faanui temp: 299.21 lat:-16.48
    Url for City: 55: marsassoum  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=marsassoum&unit=Imperial
    Processing for marsassoum temp: 300.15 lat:12.83
    Url for City: 56: samusu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=samusu&unit=Imperial
    Processing for samusu temp: 273.16 lat:41.43
    Url for City: 57: dolbeau  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=dolbeau&unit=Imperial
    Processing for dolbeau temp: 288.15 lat:48.88
    Url for City: 58: te anau  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=te anau&unit=Imperial
    Processing for te anau temp: 284.21 lat:-45.42
    Url for City: 59: morondava  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=morondava&unit=Imperial
    Processing for morondava temp: 294.61 lat:-20.28
    Url for City: 60: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 61: vao  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vao&unit=Imperial
    Processing for vao temp: 296.11 lat:-22.67
    Url for City: 62: kardla  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kardla&unit=Imperial
    Processing for kardla temp: 286.26 lat:59
    Url for City: 63: butaritari  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=butaritari&unit=Imperial
    Processing for butaritari temp: 302.31 lat:3.07
    Url for City: 64: attawapiskat  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=attawapiskat&unit=Imperial
    Processing for attawapiskat temp: 284.46 lat:52.3
    Url for City: 65: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 66: kotido  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kotido&unit=Imperial
    Processing for kotido temp: 290.71 lat:2.98
    Url for City: 67: cradock  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cradock&unit=Imperial
    Processing for cradock temp: 278.51 lat:-32.16
    Url for City: 68: kostino  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kostino&unit=Imperial
    Processing for kostino temp: 288.76 lat:58.91
    Url for City: 69: nikolskoye  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nikolskoye&unit=Imperial
    Processing for nikolskoye temp: 286.15 lat:59.68
    Url for City: 70: oranjestad  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=oranjestad&unit=Imperial
    Processing for oranjestad temp: 305.15 lat:12.52
    Url for City: 71: nelson bay  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nelson bay&unit=Imperial
    Processing for nelson bay temp: 286.15 lat:-32.72
    Url for City: 72: kutum  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kutum&unit=Imperial
    Processing for kutum temp: 295.46 lat:14.2
    Url for City: 73: aklavik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=aklavik&unit=Imperial
    Processing for aklavik temp: 290.55 lat:68.22
    Url for City: 74: dikson  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=dikson&unit=Imperial
    Processing for dikson temp: 277.31 lat:73.51
    Url for City: 75: avera  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=avera&unit=Imperial
    Processing for avera temp: 301.83 lat:33.23
    Url for City: 76: atuona  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=atuona&unit=Imperial
    Processing for atuona temp: 298.26 lat:-9.8
    Url for City: 77: clyde river  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=clyde river&unit=Imperial
    Processing for clyde river temp: 273.15 lat:70.47
    Url for City: 78: taolanaro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taolanaro&unit=Imperial
    Processing for taolanaro temp: 290.15 lat:-25.02
    Url for City: 79: clyde river  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=clyde river&unit=Imperial
    Processing for clyde river temp: 273.15 lat:70.47
    Url for City: 80: borovskoy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=borovskoy&unit=Imperial
    Processing for borovskoy temp: 286.21 lat:53.8
    Url for City: 81: puerto ayora  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=puerto ayora&unit=Imperial
    Processing for puerto ayora temp: 298.15 lat:-0.74
    Url for City: 82: pacific grove  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=pacific grove&unit=Imperial
    Processing for pacific grove temp: 294.17 lat:36.62
    Url for City: 83: taveta  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taveta&unit=Imperial
    Processing for taveta temp: 288.15 lat:-3.4
    Url for City: 84: saskylakh  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=saskylakh&unit=Imperial
    Processing for saskylakh temp: 268.91 lat:71.92
    Url for City: 85: ferrol  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ferrol&unit=Imperial
    Processing for ferrol temp: 286.03 lat:43.48
    Url for City: 86: kaitangata  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kaitangata&unit=Imperial
    Processing for kaitangata temp: 287.01 lat:-46.23
    Url for City: 87: ostersund  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ostersund&unit=Imperial
    Processing for ostersund temp: 282.15 lat:63.18
    Url for City: 88: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 89: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 90: padang  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=padang&unit=Imperial
    Processing for padang temp: 297.11 lat:-0.95
    Url for City: 91: taolanaro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taolanaro&unit=Imperial
    Processing for taolanaro temp: 290.15 lat:-25.02
    Url for City: 92: korla  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=korla&unit=Imperial
    Processing for korla temp: 288.51 lat:41.76
    Url for City: 93: vesoul  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vesoul&unit=Imperial
    Processing for vesoul temp: 283.15 lat:47.63
    Url for City: 94: upernavik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=upernavik&unit=Imperial
    Processing for upernavik temp: 275.41 lat:72.79
    Url for City: 95: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 96: illoqqortoormiut  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=illoqqortoormiut&unit=Imperial
    Processing for illoqqortoormiut temp: 294.89 lat:41.9
    Url for City: 97: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 98: viligili  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=viligili&unit=Imperial
    Processing for viligili temp: 296.11 lat:-14.56
    Url for City: 99: pisco  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=pisco&unit=Imperial
    Processing for pisco temp: 292.15 lat:-13.7
    Url for City: 100: vaini  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaini&unit=Imperial
    Processing for vaini temp: 296.15 lat:-21.2
    Url for City: 101: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 102: kenai  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kenai&unit=Imperial
    Processing for kenai temp: 285.15 lat:60.55
    Url for City: 103: yellowknife  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=yellowknife&unit=Imperial
    Processing for yellowknife temp: 283.15 lat:62.46
    Url for City: 104: srednekolymsk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=srednekolymsk&unit=Imperial
    Processing for srednekolymsk temp: 272.56 lat:67.45
    Url for City: 105: mar del plata  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mar del plata&unit=Imperial
    Processing for mar del plata temp: 286.15 lat:-38
    Url for City: 106: san andres  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=san andres&unit=Imperial
    Processing for san andres temp: 305.15 lat:12.58
    Url for City: 107: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 108: port alfred  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port alfred&unit=Imperial
    Processing for port alfred temp: 289.01 lat:-33.59
    Url for City: 109: nizhneyansk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nizhneyansk&unit=Imperial
    Processing for nizhneyansk temp: 289.15 lat:55.64
    Url for City: 110: tromso  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tromso&unit=Imperial
    Processing for tromso temp: 281.15 lat:69.65
    Url for City: 111: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 112: puerto ayora  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=puerto ayora&unit=Imperial
    Processing for puerto ayora temp: 298.15 lat:-0.74
    Url for City: 113: puerto ayora  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=puerto ayora&unit=Imperial
    Processing for puerto ayora temp: 298.15 lat:-0.74
    Url for City: 114: dalen  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=dalen&unit=Imperial
    Processing for dalen temp: 284.82 lat:52.7
    Url for City: 115: lamu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lamu&unit=Imperial
    Processing for lamu temp: 298.51 lat:-2.27
    Url for City: 116: olafsvik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=olafsvik&unit=Imperial
    Processing for olafsvik temp: 282.36 lat:64.89
    Url for City: 117: hobart  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hobart&unit=Imperial
    Processing for hobart temp: 281.15 lat:-42.88
    Url for City: 118: naze  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=naze&unit=Imperial
    Processing for naze temp: 301.71 lat:28.37
    Url for City: 119: abnub  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=abnub&unit=Imperial
    Processing for abnub temp: 299.15 lat:27.27
    Url for City: 120: tabialan  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tabialan&unit=Imperial
    Processing for tabialan temp: 301.01 lat:6.03
    Url for City: 121: geraldton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=geraldton&unit=Imperial
    Processing for geraldton temp: 285.15 lat:-28.77
    Url for City: 122: new norfolk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=new norfolk&unit=Imperial
    Processing for new norfolk temp: 281.15 lat:-42.78
    Url for City: 123: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 124: port alfred  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port alfred&unit=Imperial
    Processing for port alfred temp: 289.01 lat:-33.59
    Url for City: 125: wukari  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=wukari&unit=Imperial
    Processing for wukari temp: 299.26 lat:7.85
    Url for City: 126: asau  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=asau&unit=Imperial
    Processing for asau temp: 289.15 lat:46.43
    Url for City: 127: amnat charoen  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=amnat charoen&unit=Imperial
    Processing for amnat charoen temp: 295.46 lat:15.86
    Url for City: 128: dikson  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=dikson&unit=Imperial
    Processing for dikson temp: 277.31 lat:73.51
    Url for City: 129: taolanaro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taolanaro&unit=Imperial
    Processing for taolanaro temp: 290.15 lat:-25.02
    Url for City: 130: taoudenni  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taoudenni&unit=Imperial
    Processing for taoudenni temp: 309.11 lat:22.68
    Url for City: 131: bluff  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bluff&unit=Imperial
    Processing for bluff temp: 284.26 lat:-46.6
    Url for City: 132: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 133: arraial do cabo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=arraial do cabo&unit=Imperial
    Processing for arraial do cabo temp: 297.15 lat:-22.97
    Url for City: 134: meulaboh  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=meulaboh&unit=Imperial
    Processing for meulaboh temp: 297.26 lat:4.14
    Url for City: 135: sidi ali  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=sidi ali&unit=Imperial
    Processing for sidi ali temp: 300.33 lat:35.96
    Url for City: 136: belmonte  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=belmonte&unit=Imperial
    Processing for belmonte temp: 296.15 lat:-15.86
    Url for City: 137: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 138: tasiilaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tasiilaq&unit=Imperial
    Processing for tasiilaq temp: 278.15 lat:65.61
    Url for City: 139: tasiilaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tasiilaq&unit=Imperial
    Processing for tasiilaq temp: 278.15 lat:65.61
    Url for City: 140: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 141: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 142: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 143: brae  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=brae&unit=Imperial
    Processing for brae temp: 284.15 lat:60.4
    Url for City: 144: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 145: new norfolk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=new norfolk&unit=Imperial
    Processing for new norfolk temp: 281.15 lat:-42.78
    Url for City: 146: bredasdorp  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bredasdorp&unit=Imperial
    Processing for bredasdorp temp: 283.15 lat:-34.53
    Url for City: 147: hobart  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hobart&unit=Imperial
    Processing for hobart temp: 281.15 lat:-42.88
    Url for City: 148: lebu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lebu&unit=Imperial
    Processing for lebu temp: 283.21 lat:-37.62
    Url for City: 149: port hardy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port hardy&unit=Imperial
    Processing for port hardy temp: 287.15 lat:50.7
    Url for City: 150: katsuura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=katsuura&unit=Imperial
    Processing for katsuura temp: 295.15 lat:35.13
    Url for City: 151: huangmei  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=huangmei&unit=Imperial
    Processing for huangmei temp: 291.11 lat:30.19
    Url for City: 152: abha  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=abha&unit=Imperial
    Processing for abha temp: 294.68 lat:18.22
    Url for City: 153: saldanha  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=saldanha&unit=Imperial
    Processing for saldanha temp: 286.15 lat:-33.01
    Url for City: 154: cabo san lucas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cabo san lucas&unit=Imperial
    Processing for cabo san lucas temp: 304.28 lat:22.89
    Url for City: 155: butaritari  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=butaritari&unit=Imperial
    Processing for butaritari temp: 302.31 lat:3.07
    Url for City: 156: east london  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=east london&unit=Imperial
    Processing for east london temp: 290.71 lat:-33.02
    Url for City: 157: jamsa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=jamsa&unit=Imperial
    Processing for jamsa temp: 284.15 lat:61.86
    Url for City: 158: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 159: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 160: nanning  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nanning&unit=Imperial
    Processing for nanning temp: 300.15 lat:22.82
    Url for City: 161: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 162: neiafu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=neiafu&unit=Imperial
    Processing for neiafu temp: 297.15 lat:-18.65
    Url for City: 163: illoqqortoormiut  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=illoqqortoormiut&unit=Imperial
    Processing for illoqqortoormiut temp: 294.89 lat:41.9
    Url for City: 164: nikolskoye  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nikolskoye&unit=Imperial
    Processing for nikolskoye temp: 286.15 lat:59.68
    Url for City: 165: barrow  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barrow&unit=Imperial
    Processing for barrow temp: 276.15 lat:71.29
    Url for City: 166: hami  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hami&unit=Imperial
    Processing for hami temp: 284.46 lat:42.8
    Url for City: 167: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 168: chapais  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=chapais&unit=Imperial
    Processing for chapais temp: 285.15 lat:49.78
    Url for City: 169: cape town  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cape town&unit=Imperial
    Processing for cape town temp: 288.15 lat:-33.93
    Url for City: 170: barrow  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barrow&unit=Imperial
    Processing for barrow temp: 276.15 lat:71.29
    Url for City: 171: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 172: yellowknife  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=yellowknife&unit=Imperial
    Processing for yellowknife temp: 283.15 lat:62.46
    Url for City: 173: okhotsk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=okhotsk&unit=Imperial
    Processing for okhotsk temp: 282.46 lat:59.38
    Url for City: 174: sitka  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=sitka&unit=Imperial
    Processing for sitka temp: 285.55 lat:57.05
    Url for City: 175: hithadhoo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hithadhoo&unit=Imperial
    Processing for hithadhoo temp: 300.11 lat:-0.6
    Url for City: 176: porosozero  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=porosozero&unit=Imperial
    Processing for porosozero temp: 283.76 lat:62.72
    Url for City: 177: amderma  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=amderma&unit=Imperial
    Processing for amderma temp: 275.46 lat:69.75
    Url for City: 178: souillac  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=souillac&unit=Imperial
    Processing for souillac temp: 292.15 lat:-20.52
    Url for City: 179: samarai  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=samarai&unit=Imperial
    Processing for samarai temp: 298.61 lat:-10.62
    Url for City: 180: atuona  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=atuona&unit=Imperial
    Processing for atuona temp: 298.26 lat:-9.8
    Url for City: 181: katsiveli  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=katsiveli&unit=Imperial
    Processing for katsiveli temp: 293.01 lat:44.41
    Url for City: 182: kaitangata  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kaitangata&unit=Imperial
    Processing for kaitangata temp: 287.01 lat:-46.23
    Url for City: 183: leningradskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=leningradskiy&unit=Imperial
    Processing for leningradskiy temp: 274.71 lat:69.38
    Url for City: 184: yarada  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=yarada&unit=Imperial
    Processing for yarada temp: 301.41 lat:17.65
    Url for City: 185: umzimvubu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=umzimvubu&unit=Imperial
    Processing for umzimvubu temp: 283.01 lat:-30.55
    Url for City: 186: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 187: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 188: vigrestad  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vigrestad&unit=Imperial
    Processing for vigrestad temp: 285.15 lat:58.57
    Url for City: 189: kaeo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kaeo&unit=Imperial
    Processing for kaeo temp: 289.21 lat:-35.1
    Url for City: 190: taolanaro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taolanaro&unit=Imperial
    Processing for taolanaro temp: 290.15 lat:-25.02
    Url for City: 191: longyearbyen  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=longyearbyen&unit=Imperial
    Processing for longyearbyen temp: 277.15 lat:78.22
    Url for City: 192: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 193: marfino  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=marfino&unit=Imperial
    Processing for marfino temp: 288.41 lat:55.7
    Url for City: 194: new norfolk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=new norfolk&unit=Imperial
    Processing for new norfolk temp: 281.15 lat:-42.78
    Url for City: 195: airai  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=airai&unit=Imperial
    Processing for airai temp: 298.51 lat:25.35
    Url for City: 196: murmansk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=murmansk&unit=Imperial
    Processing for murmansk temp: 278.15 lat:68.98
    Url for City: 197: samusu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=samusu&unit=Imperial
    Processing for samusu temp: 273.16 lat:41.43
    Url for City: 198: east london  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=east london&unit=Imperial
    Processing for east london temp: 290.71 lat:-33.02
    Url for City: 199: puerto ayora  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=puerto ayora&unit=Imperial
    Processing for puerto ayora temp: 298.15 lat:-0.74
    Url for City: 200: christchurch  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=christchurch&unit=Imperial
    Processing for christchurch temp: 292.15 lat:-43.53
    Url for City: 201: yellowknife  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=yellowknife&unit=Imperial
    Processing for yellowknife temp: 283.15 lat:62.46
    Url for City: 202: bethel  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bethel&unit=Imperial
    Processing for bethel temp: 297.4 lat:41.37
    Url for City: 203: hilo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hilo&unit=Imperial
    Processing for hilo temp: 297.65 lat:19.73
    Url for City: 204: aykhal  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=aykhal&unit=Imperial
    Processing for aykhal temp: 276.41 lat:66
    Url for City: 205: kodiak  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kodiak&unit=Imperial
    Processing for kodiak temp: 286.15 lat:57.79
    Url for City: 206: norman wells  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=norman wells&unit=Imperial
    Processing for norman wells temp: 289.15 lat:65.28
    Url for City: 207: pulaski  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=pulaski&unit=Imperial
    Processing for pulaski temp: 292.45 lat:37.05
    Url for City: 208: butaritari  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=butaritari&unit=Imperial
    Processing for butaritari temp: 302.31 lat:3.07
    Url for City: 209: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 210: komsomolskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=komsomolskiy&unit=Imperial
    Processing for komsomolskiy temp: 289.56 lat:40.43
    Url for City: 211: la ronge  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=la ronge&unit=Imperial
    Processing for la ronge temp: 284.15 lat:55.1
    Url for City: 212: hilo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hilo&unit=Imperial
    Processing for hilo temp: 297.65 lat:19.73
    Url for City: 213: avarua  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=avarua&unit=Imperial
    Processing for avarua temp: 300.15 lat:-21.21
    Url for City: 214: nantucket  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nantucket&unit=Imperial
    Processing for nantucket temp: 294.76 lat:41.28
    Url for City: 215: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 216: te anau  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=te anau&unit=Imperial
    Processing for te anau temp: 284.21 lat:-45.42
    Url for City: 217: mareeba  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mareeba&unit=Imperial
    Processing for mareeba temp: 297.15 lat:-17
    Url for City: 218: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 219: bilaspur  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bilaspur&unit=Imperial
    Processing for bilaspur temp: 296.51 lat:22.08
    Url for City: 220: chokurdakh  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=chokurdakh&unit=Imperial
    Processing for chokurdakh temp: 273.46 lat:70.63
    Url for City: 221: souillac  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=souillac&unit=Imperial
    Processing for souillac temp: 292.15 lat:-20.52
    Url for City: 222: tuatapere  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tuatapere&unit=Imperial
    Processing for tuatapere temp: 281.51 lat:-46.13
    Url for City: 223: lenger  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lenger&unit=Imperial
    Processing for lenger temp: 286.15 lat:42.18
    Url for City: 224: canberra  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=canberra&unit=Imperial
    Processing for canberra temp: 283.15 lat:-35.28
    Url for City: 225: komsomolskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=komsomolskiy&unit=Imperial
    Processing for komsomolskiy temp: 289.56 lat:40.43
    Url for City: 226: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 227: umm kaddadah  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=umm kaddadah&unit=Imperial
    Processing for umm kaddadah temp: 297.76 lat:13.6
    Url for City: 228: port hedland  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port hedland&unit=Imperial
    Processing for port hedland temp: 293.15 lat:-20.32
    Url for City: 229: port alfred  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port alfred&unit=Imperial
    Processing for port alfred temp: 289.01 lat:-33.59
    Url for City: 230: ulaanbaatar  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ulaanbaatar&unit=Imperial
    Processing for ulaanbaatar temp: 279.15 lat:47.91
    Url for City: 231: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 232: new norfolk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=new norfolk&unit=Imperial
    Processing for new norfolk temp: 281.15 lat:-42.78
    Url for City: 233: qianan  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=qianan&unit=Imperial
    Processing for qianan temp: 281.76 lat:44.99
    Url for City: 234: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 235: nipawin  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nipawin&unit=Imperial
    Processing for nipawin temp: 285.15 lat:53.37
    Url for City: 236: bredasdorp  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bredasdorp&unit=Imperial
    Processing for bredasdorp temp: 283.15 lat:-34.53
    Url for City: 237: aksha  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=aksha&unit=Imperial
    Processing for aksha temp: 279.86 lat:50.28
    Url for City: 238: waipawa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=waipawa&unit=Imperial
    Processing for waipawa temp: 288.15 lat:-41.41
    Url for City: 239: tubuala  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tubuala&unit=Imperial
    Processing for tubuala temp: 302.15 lat:9.52
    Url for City: 240: kodiak  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kodiak&unit=Imperial
    Processing for kodiak temp: 286.15 lat:57.79
    Url for City: 241: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 242: bluff  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bluff&unit=Imperial
    Processing for bluff temp: 284.26 lat:-46.6
    Url for City: 243: fernie  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=fernie&unit=Imperial
    Processing for fernie temp: 286.22 lat:49.5
    Url for City: 244: znamenskoye  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=znamenskoye&unit=Imperial
    Processing for znamenskoye temp: 285.16 lat:57.13
    Url for City: 245: belushya guba  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=belushya guba&unit=Imperial
    Processing for belushya guba temp: 277.01 lat:69.71
    Url for City: 246: hudson bay  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hudson bay&unit=Imperial
    Processing for hudson bay temp: 285.96 lat:52.85
    Url for City: 247: uusikaupunki  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=uusikaupunki&unit=Imperial
    Processing for uusikaupunki temp: 284.15 lat:60.8
    Url for City: 248: westerland  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=westerland&unit=Imperial
    Processing for westerland temp: 286.15 lat:54.91
    Url for City: 249: phonhong  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=phonhong&unit=Imperial
    Processing for phonhong temp: 297.51 lat:18.49
    Url for City: 250: broome  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=broome&unit=Imperial
    Processing for broome temp: 294.15 lat:-17.97
    Url for City: 251: asau  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=asau&unit=Imperial
    Processing for asau temp: 289.15 lat:46.43
    Url for City: 252: barrow  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barrow&unit=Imperial
    Processing for barrow temp: 276.15 lat:71.29
    Url for City: 253: bluff  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bluff&unit=Imperial
    Processing for bluff temp: 284.26 lat:-46.6
    Url for City: 254: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 255: norman wells  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=norman wells&unit=Imperial
    Processing for norman wells temp: 289.15 lat:65.28
    Url for City: 256: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 257: bousso  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bousso&unit=Imperial
    Processing for bousso temp: 298.41 lat:10.48
    Url for City: 258: mar del plata  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mar del plata&unit=Imperial
    Processing for mar del plata temp: 286.15 lat:-38
    Url for City: 259: marcona  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=marcona&unit=Imperial
    Processing for marcona temp: 287.91 lat:-15.37
    Url for City: 260: lebu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lebu&unit=Imperial
    Processing for lebu temp: 283.21 lat:-37.62
    Url for City: 261: floro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=floro&unit=Imperial
    Processing for floro temp: 283.52 lat:61.6
    Url for City: 262: bluff  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bluff&unit=Imperial
    Processing for bluff temp: 284.26 lat:-46.6
    Url for City: 263: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 264: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 265: kodiak  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kodiak&unit=Imperial
    Processing for kodiak temp: 286.15 lat:57.79
    Url for City: 266: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 267: saint-philippe  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=saint-philippe&unit=Imperial
    Processing for saint-philippe temp: 293.68 lat:-21.36
    Url for City: 268: qaanaaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=qaanaaq&unit=Imperial
    Processing for qaanaaq temp: 269.26 lat:77.48
    Url for City: 269: hilo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hilo&unit=Imperial
    Processing for hilo temp: 297.65 lat:19.73
    Url for City: 270: warrnambool  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=warrnambool&unit=Imperial
    Processing for warrnambool temp: 285.46 lat:-38.38
    Url for City: 271: kodiak  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kodiak&unit=Imperial
    Processing for kodiak temp: 286.15 lat:57.79
    Url for City: 272: chuy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=chuy&unit=Imperial
    Processing for chuy temp: 289.96 lat:-33.7
    Url for City: 273: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 274: illoqqortoormiut  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=illoqqortoormiut&unit=Imperial
    Processing for illoqqortoormiut temp: 294.89 lat:41.9
    Url for City: 275: kamoke  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kamoke&unit=Imperial
    Processing for kamoke temp: 297.54 lat:31.97
    Url for City: 276: caravelas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=caravelas&unit=Imperial
    Processing for caravelas temp: 296.91 lat:-17.71
    Url for City: 277: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 278: ribeira grande  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ribeira grande&unit=Imperial
    Processing for ribeira grande temp: 296.15 lat:38.52
    Url for City: 279: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 280: baruun-urt  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=baruun-urt&unit=Imperial
    Processing for baruun-urt temp: 281.01 lat:46.68
    Url for City: 281: cherskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cherskiy&unit=Imperial
    Processing for cherskiy temp: 274.36 lat:68.75
    Url for City: 282: zhezkazgan  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=zhezkazgan&unit=Imperial
    Processing for zhezkazgan temp: 279.81 lat:47.78
    Url for City: 283: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 284: khatanga  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=khatanga&unit=Imperial
    Processing for khatanga temp: 275.76 lat:71.97
    Url for City: 285: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 286: hilo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hilo&unit=Imperial
    Processing for hilo temp: 297.65 lat:19.73
    Url for City: 287: butaritari  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=butaritari&unit=Imperial
    Processing for butaritari temp: 302.31 lat:3.07
    Url for City: 288: ponta do sol  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ponta do sol&unit=Imperial
    Processing for ponta do sol temp: 295.15 lat:32.67
    Url for City: 289: sentyabrskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=sentyabrskiy&unit=Imperial
    Processing for sentyabrskiy temp: 279.96 lat:60.75
    Url for City: 290: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 291: taoudenni  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taoudenni&unit=Imperial
    Processing for taoudenni temp: 309.11 lat:22.68
    Url for City: 292: bonthe  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bonthe&unit=Imperial
    Processing for bonthe temp: 297.41 lat:7.53
    Url for City: 293: bethel  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bethel&unit=Imperial
    Processing for bethel temp: 297.4 lat:41.37
    Url for City: 294: morondava  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=morondava&unit=Imperial
    Processing for morondava temp: 294.61 lat:-20.28
    Url for City: 295: hilo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hilo&unit=Imperial
    Processing for hilo temp: 297.65 lat:19.73
    Url for City: 296: bondoukou  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bondoukou&unit=Imperial
    Processing for bondoukou temp: 297.36 lat:8.03
    Url for City: 297: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 298: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 299: hermanus  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hermanus&unit=Imperial
    Processing for hermanus temp: 282.41 lat:-34.42
    Url for City: 300: saleaula  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=saleaula&unit=Imperial
    Processing for saleaula temp: 297.15 lat:17.31
    Url for City: 301: puerto ayora  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=puerto ayora&unit=Imperial
    Processing for puerto ayora temp: 298.15 lat:-0.74
    Url for City: 302: francistown  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=francistown&unit=Imperial
    Processing for francistown temp: 292.11 lat:-21.17
    Url for City: 303: toliary  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=toliary&unit=Imperial
    Processing for toliary temp: 291.91 lat:-23.35
    Url for City: 304: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 305: lukovetskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lukovetskiy&unit=Imperial
    Processing for lukovetskiy temp: 283.15 lat:64.3
    Url for City: 306: san matias  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=san matias&unit=Imperial
    Processing for san matias temp: 307.86 lat:-16.37
    Url for City: 307: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 308: muzhi  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=muzhi&unit=Imperial
    Processing for muzhi temp: 273.01 lat:65.37
    Url for City: 309: bredasdorp  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bredasdorp&unit=Imperial
    Processing for bredasdorp temp: 283.15 lat:-34.53
    Url for City: 310: san patricio  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=san patricio&unit=Imperial
    Processing for san patricio temp: 305.15 lat:19.22
    Url for City: 311: kenai  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kenai&unit=Imperial
    Processing for kenai temp: 285.15 lat:60.55
    Url for City: 312: taolanaro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taolanaro&unit=Imperial
    Processing for taolanaro temp: 290.15 lat:-25.02
    Url for City: 313: cape town  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cape town&unit=Imperial
    Processing for cape town temp: 288.15 lat:-33.93
    Url for City: 314: illoqqortoormiut  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=illoqqortoormiut&unit=Imperial
    Processing for illoqqortoormiut temp: 294.89 lat:41.9
    Url for City: 315: kousseri  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kousseri&unit=Imperial
    Processing for kousseri temp: 298.15 lat:12.08
    Url for City: 316: san quintin  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=san quintin&unit=Imperial
    Processing for san quintin temp: 297.46 lat:30.48
    Url for City: 317: navoi  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=navoi&unit=Imperial
    Processing for navoi temp: 301.15 lat:19.03
    Url for City: 318: vaini  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaini&unit=Imperial
    Processing for vaini temp: 296.15 lat:-21.2
    Url for City: 319: amderma  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=amderma&unit=Imperial
    Processing for amderma temp: 275.46 lat:69.75
    Url for City: 320: port alfred  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port alfred&unit=Imperial
    Processing for port alfred temp: 289.01 lat:-33.59
    Url for City: 321: huilong  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=huilong&unit=Imperial
    Processing for huilong temp: 297.31 lat:31.81
    Url for City: 322: farafangana  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=farafangana&unit=Imperial
    Processing for farafangana temp: 295.21 lat:-22.82
    Url for City: 323: ravar  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ravar&unit=Imperial
    Processing for ravar temp: 286.46 lat:31.27
    Url for City: 324: butaritari  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=butaritari&unit=Imperial
    Processing for butaritari temp: 302.31 lat:3.07
    Url for City: 325: qaanaaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=qaanaaq&unit=Imperial
    Processing for qaanaaq temp: 269.26 lat:77.48
    Url for City: 326: bambous virieux  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bambous virieux&unit=Imperial
    Processing for bambous virieux temp: 292.15 lat:-20.34
    Url for City: 327: dickinson  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=dickinson&unit=Imperial
    Processing for dickinson temp: 304.91 lat:29.46
    Url for City: 328: energetik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=energetik&unit=Imperial
    Processing for energetik temp: 286.31 lat:51.74
    Url for City: 329: norman wells  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=norman wells&unit=Imperial
    Processing for norman wells temp: 289.15 lat:65.28
    Url for City: 330: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 331: san vicente  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=san vicente&unit=Imperial
    Processing for san vicente temp: 297.21 lat:-26.62
    Url for City: 332: vrangel  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vrangel&unit=Imperial
    Processing for vrangel temp: 288.96 lat:42.73
    Url for City: 333: cape town  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cape town&unit=Imperial
    Processing for cape town temp: 288.15 lat:-33.93
    Url for City: 334: santa isabel do rio negro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=santa isabel do rio negro&unit=Imperial
    Processing for santa isabel do rio negro temp: 301.11 lat:-0.41
    Url for City: 335: barrow  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barrow&unit=Imperial
    Processing for barrow temp: 276.15 lat:71.29
    Url for City: 336: mar del plata  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mar del plata&unit=Imperial
    Processing for mar del plata temp: 286.15 lat:-38
    Url for City: 337: bredasdorp  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bredasdorp&unit=Imperial
    Processing for bredasdorp temp: 283.15 lat:-34.53
    Url for City: 338: khatanga  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=khatanga&unit=Imperial
    Processing for khatanga temp: 275.76 lat:71.97
    Url for City: 339: tasiilaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tasiilaq&unit=Imperial
    Processing for tasiilaq temp: 278.15 lat:65.61
    Url for City: 340: atuona  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=atuona&unit=Imperial
    Processing for atuona temp: 298.26 lat:-9.8
    Url for City: 341: jamestown  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=jamestown&unit=Imperial
    Processing for jamestown temp: 292.53 lat:42.1
    Url for City: 342: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 343: bengkulu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bengkulu&unit=Imperial
    Processing for bengkulu temp: 296.71 lat:-3.8
    Url for City: 344: murgab  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=murgab&unit=Imperial
    Processing for murgab temp: 286.71 lat:37.5
    Url for City: 345: east london  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=east london&unit=Imperial
    Processing for east london temp: 290.71 lat:-33.02
    Url for City: 346: lorengau  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lorengau&unit=Imperial
    Processing for lorengau temp: 299.15 lat:-2.02
    Url for City: 347: carnarvon  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=carnarvon&unit=Imperial
    Processing for carnarvon temp: 290.96 lat:-24.87
    Url for City: 348: chuy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=chuy&unit=Imperial
    Processing for chuy temp: 289.96 lat:-33.7
    Url for City: 349: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 350: palabuhanratu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=palabuhanratu&unit=Imperial
    Processing for palabuhanratu temp: 298.46 lat:-6.95
    Url for City: 351: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 352: popondetta  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=popondetta&unit=Imperial
    Processing for popondetta temp: 292.56 lat:-8.75
    Url for City: 353: hobart  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hobart&unit=Imperial
    Processing for hobart temp: 281.15 lat:-42.88
    Url for City: 354: umm ruwabah  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=umm ruwabah&unit=Imperial
    Processing for umm ruwabah temp: 301.16 lat:13.7
    Url for City: 355: senador jose porfirio  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=senador jose porfirio&unit=Imperial
    Processing for senador jose porfirio temp: 304.36 lat:-2.59
    Url for City: 356: cherskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cherskiy&unit=Imperial
    Processing for cherskiy temp: 274.36 lat:68.75
    Url for City: 357: urumqi  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=urumqi&unit=Imperial
    Processing for urumqi temp: 286.15 lat:43.8
    Url for City: 358: oistins  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=oistins&unit=Imperial
    Processing for oistins temp: 300.15 lat:13.07
    Url for City: 359: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 360: jiangyou  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=jiangyou&unit=Imperial
    Processing for jiangyou temp: 292.21 lat:31.77
    Url for City: 361: thompson  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=thompson&unit=Imperial
    Processing for thompson temp: 284.15 lat:55.74
    Url for City: 362: nikolskoye  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nikolskoye&unit=Imperial
    Processing for nikolskoye temp: 286.15 lat:59.68
    Url for City: 363: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 364: tuktoyaktuk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tuktoyaktuk&unit=Imperial
    Processing for tuktoyaktuk temp: 284.15 lat:69.45
    Url for City: 365: ouallam  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ouallam&unit=Imperial
    Processing for ouallam temp: 301.16 lat:14.32
    Url for City: 366: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 367: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 368: gunjur  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=gunjur&unit=Imperial
    Processing for gunjur temp: 300.15 lat:13.2
    Url for City: 369: punta arenas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=punta arenas&unit=Imperial
    Processing for punta arenas temp: 278.15 lat:-53.15
    Url for City: 370: zyryanka  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=zyryanka&unit=Imperial
    Processing for zyryanka temp: 273.41 lat:65.75
    Url for City: 371: batagay-alyta  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=batagay-alyta&unit=Imperial
    Processing for batagay-alyta temp: 271.61 lat:67.8
    Url for City: 372: hobart  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hobart&unit=Imperial
    Processing for hobart temp: 281.15 lat:-42.88
    Url for City: 373: latung  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=latung&unit=Imperial
    Processing for latung temp: 301.21 lat:5.5
    Url for City: 374: anchorage  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=anchorage&unit=Imperial
    Processing for anchorage temp: 284.64 lat:61.22
    Url for City: 375: plettenberg bay  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=plettenberg bay&unit=Imperial
    Processing for plettenberg bay temp: 289.01 lat:-34.05
    Url for City: 376: vaini  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaini&unit=Imperial
    Processing for vaini temp: 296.15 lat:-21.2
    Url for City: 377: marzuq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=marzuq&unit=Imperial
    Processing for marzuq temp: 300.01 lat:14.25
    Url for City: 378: barrow  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barrow&unit=Imperial
    Processing for barrow temp: 276.15 lat:71.29
    Url for City: 379: thinadhoo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=thinadhoo&unit=Imperial
    Processing for thinadhoo temp: 300.71 lat:0.53
    Url for City: 380: sao gabriel da cachoeira  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=sao gabriel da cachoeira&unit=Imperial
    Processing for sao gabriel da cachoeira temp: 302.76 lat:-0.13
    Url for City: 381: port hardy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port hardy&unit=Imperial
    Processing for port hardy temp: 287.15 lat:50.7
    Url for City: 382: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 383: pervomayskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=pervomayskiy&unit=Imperial
    Processing for pervomayskiy temp: 290.01 lat:53.25
    Url for City: 384: vaini  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaini&unit=Imperial
    Processing for vaini temp: 296.15 lat:-21.2
    Url for City: 385: komsomolskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=komsomolskiy&unit=Imperial
    Processing for komsomolskiy temp: 289.56 lat:40.43
    Url for City: 386: angoche  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=angoche&unit=Imperial
    Processing for angoche temp: 296.96 lat:-16.23
    Url for City: 387: sungaipenuh  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=sungaipenuh&unit=Imperial
    Processing for sungaipenuh temp: 291.31 lat:-2.08
    Url for City: 388: avarua  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=avarua&unit=Imperial
    Processing for avarua temp: 300.15 lat:-21.21
    Url for City: 389: muisne  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=muisne&unit=Imperial
    Processing for muisne temp: 300.11 lat:0.6
    Url for City: 390: atuona  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=atuona&unit=Imperial
    Processing for atuona temp: 298.26 lat:-9.8
    Url for City: 391: klaksvik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=klaksvik&unit=Imperial
    Processing for klaksvik temp: 282.15 lat:62.23
    Url for City: 392: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 393: monte alegre de minas  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=monte alegre de minas&unit=Imperial
    Processing for monte alegre de minas temp: 301.41 lat:-18.87
    Url for City: 394: cape town  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cape town&unit=Imperial
    Processing for cape town temp: 288.15 lat:-33.93
    Url for City: 395: clyde river  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=clyde river&unit=Imperial
    Processing for clyde river temp: 273.15 lat:70.47
    Url for City: 396: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 397: grindavik  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=grindavik&unit=Imperial
    Processing for grindavik temp: 282.15 lat:63.84
    Url for City: 398: alofi  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=alofi&unit=Imperial
    Processing for alofi temp: 298.15 lat:-19.06
    Url for City: 399: tasiilaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tasiilaq&unit=Imperial
    Processing for tasiilaq temp: 278.15 lat:65.61
    Url for City: 400: college  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=college&unit=Imperial
    Processing for college temp: 288.12 lat:64.86
    Url for City: 401: lixourion  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lixourion&unit=Imperial
    Processing for lixourion temp: 296.61 lat:38.2
    Url for City: 402: port alfred  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port alfred&unit=Imperial
    Processing for port alfred temp: 289.01 lat:-33.59
    Url for City: 403: bambous virieux  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bambous virieux&unit=Imperial
    Processing for bambous virieux temp: 292.15 lat:-20.34
    Url for City: 404: evensk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=evensk&unit=Imperial
    Processing for evensk temp: 277.11 lat:61.95
    Url for City: 405: tasiilaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tasiilaq&unit=Imperial
    Processing for tasiilaq temp: 278.15 lat:65.61
    Url for City: 406: hithadhoo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hithadhoo&unit=Imperial
    Processing for hithadhoo temp: 300.11 lat:-0.6
    Url for City: 407: hilo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hilo&unit=Imperial
    Processing for hilo temp: 297.65 lat:19.73
    Url for City: 408: lebu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lebu&unit=Imperial
    Processing for lebu temp: 283.21 lat:-37.62
    Url for City: 409: hobart  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hobart&unit=Imperial
    Processing for hobart temp: 281.15 lat:-42.88
    Url for City: 410: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 411: fairbanks  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=fairbanks&unit=Imperial
    Processing for fairbanks temp: 288.12 lat:64.84
    Url for City: 412: kursenai  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kursenai&unit=Imperial
    Processing for kursenai temp: 285.15 lat:55.98
    Url for City: 413: port lincoln  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port lincoln&unit=Imperial
    Processing for port lincoln temp: 286.16 lat:-34.73
    Url for City: 414: lata  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lata&unit=Imperial
    Processing for lata temp: 289.15 lat:40.16
    Url for City: 415: acajutla  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=acajutla&unit=Imperial
    Processing for acajutla temp: 300.07 lat:13.59
    Url for City: 416: grand river south east  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=grand river south east&unit=Imperial
    Processing for grand river south east temp: 292.15 lat:-20.29
    Url for City: 417: kaitangata  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kaitangata&unit=Imperial
    Processing for kaitangata temp: 287.01 lat:-46.23
    Url for City: 418: dikson  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=dikson&unit=Imperial
    Processing for dikson temp: 277.31 lat:73.51
    Url for City: 419: hami  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hami&unit=Imperial
    Processing for hami temp: 284.46 lat:42.8
    Url for City: 420: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 421: madang  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=madang&unit=Imperial
    Processing for madang temp: 297.61 lat:-5.22
    Url for City: 422: ponta do sol  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ponta do sol&unit=Imperial
    Processing for ponta do sol temp: 295.15 lat:32.67
    Url for City: 423: ixtapa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ixtapa&unit=Imperial
    Processing for ixtapa temp: 305.15 lat:20.7
    Url for City: 424: amahai  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=amahai&unit=Imperial
    Processing for amahai temp: 297.41 lat:-3.33
    Url for City: 425: faanui  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=faanui&unit=Imperial
    Processing for faanui temp: 299.21 lat:-16.48
    Url for City: 426: hobart  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hobart&unit=Imperial
    Processing for hobart temp: 281.15 lat:-42.88
    Url for City: 427: cherskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cherskiy&unit=Imperial
    Processing for cherskiy temp: 274.36 lat:68.75
    Url for City: 428: castro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=castro&unit=Imperial
    Processing for castro temp: 297.91 lat:-24.79
    Url for City: 429: rikitea  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=rikitea&unit=Imperial
    Processing for rikitea temp: 294.56 lat:-23.12
    Url for City: 430: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 431: svetlogorsk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=svetlogorsk&unit=Imperial
    Processing for svetlogorsk temp: 291.86 lat:52.63
    Url for City: 432: tuktoyaktuk  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tuktoyaktuk&unit=Imperial
    Processing for tuktoyaktuk temp: 284.15 lat:69.45
    Url for City: 433: tuatapere  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=tuatapere&unit=Imperial
    Processing for tuatapere temp: 281.51 lat:-46.13
    Url for City: 434: qaanaaq  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=qaanaaq&unit=Imperial
    Processing for qaanaaq temp: 269.26 lat:77.48
    Url for City: 435: bolshoy uluy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=bolshoy uluy&unit=Imperial
    Processing for bolshoy uluy temp: 278.11 lat:56.95
    Url for City: 436: barrow  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barrow&unit=Imperial
    Processing for barrow temp: 276.15 lat:71.29
    Url for City: 437: ancud  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ancud&unit=Imperial
    Processing for ancud temp: 282.01 lat:-41.87
    Url for City: 438: shubarshi  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=shubarshi&unit=Imperial
    Processing for shubarshi temp: 287.21 lat:48.59
    Url for City: 439: avarua  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=avarua&unit=Imperial
    Processing for avarua temp: 300.15 lat:-21.21
    Url for City: 440: longyearbyen  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=longyearbyen&unit=Imperial
    Processing for longyearbyen temp: 277.15 lat:78.22
    Url for City: 441: college  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=college&unit=Imperial
    Processing for college temp: 288.12 lat:64.86
    Url for City: 442: san ramon de la nueva oran  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=san ramon de la nueva oran&unit=Imperial
    Processing for san ramon de la nueva oran temp: 296.46 lat:-23.13
    Url for City: 443: san cristobal  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=san cristobal&unit=Imperial
    Processing for san cristobal temp: 304.15 lat:7.77
    Url for City: 444: hilo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hilo&unit=Imperial
    Processing for hilo temp: 297.65 lat:19.73
    Url for City: 445: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 446: mahebourg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mahebourg&unit=Imperial
    Processing for mahebourg temp: 292.15 lat:-20.41
    Url for City: 447: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 448: dingle  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=dingle&unit=Imperial
    Processing for dingle temp: 295.86 lat:11
    Url for City: 449: barentsburg  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=barentsburg&unit=Imperial
    Processing for barentsburg temp: 285.67 lat:52.62
    Url for City: 450: vaini  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaini&unit=Imperial
    Processing for vaini temp: 296.15 lat:-21.2
    Url for City: 451: komsomolskiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=komsomolskiy&unit=Imperial
    Processing for komsomolskiy temp: 289.56 lat:40.43
    Url for City: 452: shirokiy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=shirokiy&unit=Imperial
    Processing for shirokiy temp: 285.11 lat:49.76
    Url for City: 453: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 454: lluta  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lluta&unit=Imperial
    Processing for lluta temp: 292.15 lat:-16.01
    Url for City: 455: vao  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vao&unit=Imperial
    Processing for vao temp: 296.11 lat:-22.67
    Url for City: 456: college  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=college&unit=Imperial
    Processing for college temp: 288.12 lat:64.86
    Url for City: 457: samusu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=samusu&unit=Imperial
    Processing for samusu temp: 273.16 lat:41.43
    Url for City: 458: vaitupu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaitupu&unit=Imperial
    Processing for vaitupu temp: 305.15 lat:-17.8
    Url for City: 459: deer lake  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=deer lake&unit=Imperial
    Processing for deer lake temp: 290.15 lat:49.17
    Url for City: 460: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 461: padang  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=padang&unit=Imperial
    Processing for padang temp: 297.11 lat:-0.95
    Url for City: 462: pevek  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=pevek&unit=Imperial
    Processing for pevek temp: 275.66 lat:69.7
    Url for City: 463: ushuaia  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ushuaia&unit=Imperial
    Processing for ushuaia temp: 276.15 lat:-54.8
    Url for City: 464: busselton  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=busselton&unit=Imperial
    Processing for busselton temp: 287.46 lat:-33.65
    Url for City: 465: cockburn town  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=cockburn town&unit=Imperial
    Processing for cockburn town temp: 301.71 lat:21.46
    Url for City: 466: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 467: vanavara  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vanavara&unit=Imperial
    Processing for vanavara temp: 275.21 lat:60.34
    Url for City: 468: el alto  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=el alto&unit=Imperial
    Processing for el alto temp: 299.81 lat:-4.27
    Url for City: 469: omboue  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=omboue&unit=Imperial
    Processing for omboue temp: 297.41 lat:-1.57
    Url for City: 470: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 471: mataura  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mataura&unit=Imperial
    Processing for mataura temp: 296.96 lat:27.5
    Url for City: 472: albany  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=albany&unit=Imperial
    Processing for albany temp: 297.53 lat:42.65
    Url for City: 473: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 474: kruisfontein  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kruisfontein&unit=Imperial
    Processing for kruisfontein temp: 287.51 lat:-34
    Url for City: 475: illoqqortoormiut  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=illoqqortoormiut&unit=Imperial
    Processing for illoqqortoormiut temp: 294.89 lat:41.9
    Url for City: 476: butaritari  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=butaritari&unit=Imperial
    Processing for butaritari temp: 302.31 lat:3.07
    Url for City: 477: georgetown  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=georgetown&unit=Imperial
    Processing for georgetown temp: 304.15 lat:6.8
    Url for City: 478: ostrovnoy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ostrovnoy&unit=Imperial
    Processing for ostrovnoy temp: 279.26 lat:68.05
    Url for City: 479: vaini  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=vaini&unit=Imperial
    Processing for vaini temp: 296.15 lat:-21.2
    Url for City: 480: raga  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=raga&unit=Imperial
    Processing for raga temp: 293.01 lat:8.46
    Url for City: 481: illoqqortoormiut  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=illoqqortoormiut&unit=Imperial
    Processing for illoqqortoormiut temp: 294.89 lat:41.9
    Url for City: 482: iqaluit  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=iqaluit&unit=Imperial
    Processing for iqaluit temp: 280.15 lat:63.75
    Url for City: 483: port lincoln  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=port lincoln&unit=Imperial
    Processing for port lincoln temp: 286.16 lat:-34.73
    Url for City: 484: nhulunbuy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=nhulunbuy&unit=Imperial
    Processing for nhulunbuy temp: 299.15 lat:-12.23
    Url for City: 485: mys shmidta  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=mys shmidta&unit=Imperial
    Processing for mys shmidta temp: 287.86 lat:47.75
    Url for City: 486: saldanha  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=saldanha&unit=Imperial
    Processing for saldanha temp: 286.15 lat:-33.01
    Url for City: 487: taolanaro  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=taolanaro&unit=Imperial
    Processing for taolanaro temp: 290.15 lat:-25.02
    Url for City: 488: chapais  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=chapais&unit=Imperial
    Processing for chapais temp: 285.15 lat:49.78
    Url for City: 489: alofi  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=alofi&unit=Imperial
    Processing for alofi temp: 298.15 lat:-19.06
    Url for City: 490: kapaa  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=kapaa&unit=Imperial
    Processing for kapaa temp: 302.15 lat:22.08
    Url for City: 491: hami  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=hami&unit=Imperial
    Processing for hami temp: 284.46 lat:42.8
    Url for City: 492: temascalcingo  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=temascalcingo&unit=Imperial
    Processing for temascalcingo temp: 297.51 lat:19.92
    Url for City: 493: attawapiskat  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=attawapiskat&unit=Imperial
    Processing for attawapiskat temp: 284.46 lat:52.3
    Url for City: 494: chuy  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=chuy&unit=Imperial
    Processing for chuy temp: 289.96 lat:-33.7
    Url for City: 495: portpatrick  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=portpatrick&unit=Imperial
    Processing for portpatrick temp: 284.15 lat:54.9
    Url for City: 496: ponta do sol  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=ponta do sol&unit=Imperial
    Processing for ponta do sol temp: 295.15 lat:32.67
    Url for City: 497: lebu  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=lebu&unit=Imperial
    Processing for lebu temp: 283.21 lat:-37.62
    Url for City: 498: pevek  http://api.openweathermap.org/data/2.5/weather?appid=76c9ea83e90e1872de2dc5f6859ac904&q=pevek&unit=Imperial
    Processing for pevek temp: 275.66 lat:69.7
    


```python
#Save data
print("Save Data Retrived")
allValDf.to_csv('Resources/CitiesNearEquator.csv')
```

    Save Data Retrived
    


```python
print("  -----    Plot the Temperature against Latitude ----- ")
plt.figure(figsize=(16, 6))
plt.grid = True
plt.plot(lats,temps,marker = 'o',color="red", alpha=0.75,label="Temperature (F)", linewidth='0.0')
plt.suptitle('Relationship between Latitude and Temperature', fontsize=20)
plt.xlabel("Latitude" , fontsize=15)
plt.ylabel("Temperature (F)", fontsize=15)
plt.legend()
plt.show()

# Save Plot
plt.savefig("LatitudeTemp.png")
```

      -----    Plot the Temperature against Latitude ----- 
    


    <matplotlib.figure.Figure at 0x1fb72f93240>



![png](output_5_2.png)



```python
print("  -----    Plot the Humidity against Latitude ----- ")
plt.figure(figsize=(16, 6))
plt.grid = True
plt.plot(lats,humids,marker = 'X',color="blue", alpha=0.75,label="Humidity %", linewidth='0.0')
plt.suptitle('Relationship between Latitude and Humidity', fontsize=20)
plt.xlabel("Latitude" , fontsize=15)
plt.ylabel("Humidity", fontsize=15)
plt.legend()
plt.show()
# Save Plot
plt.savefig("LatitudeHumid.png")
```

      -----    Plot the Humidity against Latitude ----- 
    


    <matplotlib.figure.Figure at 0x1fb72b33780>



![png](output_6_2.png)



```python
print("  -----    Plot the Cloudiness against Latitude ----- ")
plt.figure(figsize=(16, 6))
plt.grid = True
plt.plot(lats,cloudies,marker = '^',color='gold', alpha=0.75, label="Cloudiness", linewidth='0.0')
plt.suptitle('Relationship between Latitude and Cloudiness', fontsize=20)
plt.xlabel("Latitude" , fontsize=15)
plt.ylabel("Cloudiness ", fontsize=15)
plt.legend()
plt.show()
# Save Plot
plt.savefig("LatitudeClouds.png")
```

      -----    Plot the Cloudiness against Latitude ----- 
    


    <matplotlib.figure.Figure at 0x1fb7305e438>



![png](output_7_2.png)



```python
print("  -----    Plot the Wind Speeds against Latitude ----- ")
plt.figure(figsize=(16, 6))
plt.grid = True
plt.plot(lats,winds,marker = '+',color="green", alpha=0.75,label="Wind Speed m/h", linewidth='0.0')
plt.suptitle('Relationship between Latitude and Wind Speed', fontsize=20)
plt.xlabel("Latitude" , fontsize=15)
plt.ylabel("Wind Speed M/h ", fontsize=15)
plt.legend()
plt.show()
# Save Plot
plt.savefig("LatitudeWinds.png")
```

      -----    Plot the Wind Speeds against Latitude ----- 
    


    <matplotlib.figure.Figure at 0x1fb72f63f60>



![png](output_8_2.png)


# Observations
### 1. Temprature rises as you get closer to the Equator (I think we know that)....
### 2. While there does not seem to be an obvious relationship between the equator and clodiness, it does appear that it gets clouded as we go on higher latitudes from the Equator
### 3. The wind speeds are not closely related to the Equator at all


```python

```


```python

```
